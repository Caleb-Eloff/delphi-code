unit MyFlights_u;

interface

uses
  Winapi.Windows, Winapi.Messages,
  System.SysUtils, System.Variants, System.Classes, System.Math,
  Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls,
  Vcl.StdCtrls, Vcl.Grids,
  dmAccounts_u;

type
  TfrmMyFlights = class(TForm)
    imgMyFlightsBackground: TImage;
    lblBookedFlights: TLabel;
    sgBookedFlights: TStringGrid;
    btnRemove: TButton;
    btnUndo: TButton;
    btnSearch: TButton;
    memFlightDetails: TMemo;
    lblMyFlightDetails: TLabel;
    btnMyFlightsBack: TButton;

    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormShow(Sender: TObject);

    procedure btnMyFlightsBackClick(Sender: TObject);
    procedure btnFlightDetailsSaveClick(Sender: TObject);
    procedure btnSearchClick(Sender: TObject);
    procedure btnRemoveClick(Sender: TObject);
    procedure btnUndoClick(Sender: TObject);

  private
    { Helper methods that make code easier to read }
    procedure SetupGridHeaders;
    procedure ClearGridData;
    procedure FormatGridColumns;

    function StartsWith(const S, Prefix: string): Boolean;
    function ExtractValueAfterColon(const Line: string): string;
    function ParsePriceToFloat(const PriceText: string): Double;
    function SafeStrToIntDef(const S: string; const Default: Integer): Integer;

    procedure LoadBookingsFromFile(const FileName: string);
    procedure RemoveBookingFromFile(const FileName, TargetFlightID: string);
    procedure RestoreBookingToFile(const UserID: string);

    procedure RefreshSummaryMemo(const FullName: string);

  public
    { Public members (available outside the form) }
  end;

var
  frmMyFlights: TfrmMyFlights;

  // Stores the last deleted row so we can undo.
  // Index mapping (columns):
  // 0=FlightID, 1=From, 2=To, 3=Class, 4=Seats, 5=Price/Seat, 6=Departure Date
  gLastDeletedRowData: array [0 .. 6] of string;
  gLastDeletedRowIndex: Integer = -1;
  gUndoAvailable: Boolean = False;

implementation

{$R *.dfm}

uses
  Home_u, LoginRegister_u;

const
  // Column indices for readability
  COL_FLIGHTID = 0;
  COL_FROM = 1;
  COL_TO = 2;
  COL_CLASS = 3;
  COL_SEATS = 4;
  COL_PRICE_PER = 5;
  COL_DEPARTUREDATE = 6;

  GRID_COL_COUNT = 7;

  { ============================ BASIC HELPERS ============================ }

function TfrmMyFlights.StartsWith(const S, Prefix: string): Boolean;
begin
  // Simple, case-sensitive "starts with" check
  Result := Copy(S, 1, Length(Prefix)) = Prefix;
end;

function TfrmMyFlights.ExtractValueAfterColon(const Line: string): string;
var
  P: Integer;
begin
  // Given "Key: Value", returns "Value" (trimmed). If no colon, return whole line trimmed.
  P := Pos(':', Line);
  if P > 0 then
    Result := Trim(Copy(Line, P + 1, MaxInt))
  else
    Result := Trim(Line);
end;

function TfrmMyFlights.ParsePriceToFloat(const PriceText: string): Double;
var
  CleanText: string;
begin
  // Accepts "R123.45" or "123.45" or "R 123,45" (common variants)
  CleanText := PriceText;
  CleanText := StringReplace(CleanText, 'R', '', [rfReplaceAll, rfIgnoreCase]);
  CleanText := StringReplace(CleanText, ' ', '', [rfReplaceAll]);
  CleanText := StringReplace(CleanText, ',', '.', [rfReplaceAll]);
  // just in case

  if not TryStrToFloat(CleanText, Result) then
    Result := 0.0;
end;

function TfrmMyFlights.SafeStrToIntDef(const S: string;
  const Default: Integer): Integer;
begin
  if not TryStrToInt(Trim(S), Result) then
    Result := Default;
end;

{ ============================ GRID HELPERS ============================ }

procedure TfrmMyFlights.SetupGridHeaders;
begin
  // Ensure the grid has the right number of columns and a header row
  sgBookedFlights.ColCount := GRID_COL_COUNT;
  sgBookedFlights.FixedRows := 1; // 1 header row
  sgBookedFlights.RowCount := Max(sgBookedFlights.RowCount, 2);
  // keep at least header + 1 data row

  // Header texts
  sgBookedFlights.Cells[COL_FLIGHTID, 0] := 'FlightID';
  sgBookedFlights.Cells[COL_FROM, 0] := 'From';
  sgBookedFlights.Cells[COL_TO, 0] := 'To';
  sgBookedFlights.Cells[COL_CLASS, 0] := 'Class';
  sgBookedFlights.Cells[COL_SEATS, 0] := 'Seats';
  sgBookedFlights.Cells[COL_PRICE_PER, 0] := 'Price/Seat';
  sgBookedFlights.Cells[COL_DEPARTUREDATE, 0] := 'Departure Date';

  FormatGridColumns;
end;

procedure TfrmMyFlights.ClearGridData;
var
  R, C: Integer;
begin
  // Reset to header + one empty data row
  sgBookedFlights.RowCount := 2;
  for R := 1 to sgBookedFlights.RowCount - 1 do
    for C := 0 to sgBookedFlights.ColCount - 1 do
      sgBookedFlights.Cells[C, R] := '';
end;

procedure TfrmMyFlights.FormatGridColumns;
var
  C, ColWidth: Integer;
begin
  // Simple equal-width columns. Adjust if you want specific widths.
  if sgBookedFlights.ColCount = 0 then
    Exit;
  ColWidth := Max(60, sgBookedFlights.ClientWidth div sgBookedFlights.ColCount);
  for C := 0 to sgBookedFlights.ColCount - 1 do
    sgBookedFlights.ColWidths[C] := ColWidth;
end;

{ ============================ UI EVENTS ============================ }

procedure TfrmMyFlights.FormCreate(Sender: TObject);
begin
  // Make the form take up the full screen and hide borders (your original behavior)
  BorderStyle := bsNone;
  SetBounds(0, 0, Screen.Width, Screen.Height);
  WindowState := wsMaximized;

  // Background
  if FileExists('Background.png') then
    imgMyFlightsBackground.Picture.LoadFromFile('Background.png');

  // Grid header setup
  SetupGridHeaders;
  ClearGridData;

  // Nothing is deleted yet, so undo is not available
  gUndoAvailable := False;
  gLastDeletedRowIndex := -1;
end;

procedure TfrmMyFlights.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Application.Terminate;
end;

procedure TfrmMyFlights.btnMyFlightsBackClick(Sender: TObject);
begin
  Hide;
  frmHome.Show;
end;

procedure TfrmMyFlights.btnFlightDetailsSaveClick(Sender: TObject);
var
  BookingFile: string;
  BookingData: TStringList;
begin
  // The final booking file for the logged-in user
  BookingFile := frmLoginRegister.sUserID + '_Booking.txt';

  // Save changes directly into the database
  dmAccounts.tblFlights.Post;

  // Also save booking details into a text file (for reference / backup)
  BookingData := TStringList.Create;
  try
    BookingData.Add('UserID: ' + frmLoginRegister.sUserID);
    BookingData.Add('From: ' + dmAccounts.tblFlights.FieldByName('FromDest')
      .AsString);
    BookingData.Add('To: ' + dmAccounts.tblFlights.FieldByName('ToDest')
      .AsString);
    BookingData.Add('Class: ' + dmAccounts.tblFlights.FieldByName('Class')
      .AsString);
    BookingData.Add('Seats: ' + dmAccounts.tblFlights.FieldByName('Seats')
      .AsString);
    BookingData.Add('Total Price: ' + dmAccounts.tblFlights.FieldByName
      ('TotalPrice').AsString);
    BookingData.Add('Booking Date: ' +
      DateTimeToStr(dmAccounts.tblFlights.FieldByName('BookingDate')
      .AsDateTime));
    BookingData.Add('Departure Date: ' +
      DateToStr(dmAccounts.tblFlights.FieldByName('DepartureDate').AsDateTime));

    BookingData.SaveToFile(BookingFile); // save directly, no temp file needed
  finally
    BookingData.Free;
  end;

  ShowMessage('Changes saved successfully to database and file.');
end;

procedure TfrmMyFlights.btnSearchClick(Sender: TObject);
var
  SearchID: string;
  RowIndex: Integer;
begin
  SearchID := InputBox('Search Flight', 'Enter FlightID:', '');
  if SearchID = '' then
    Exit;

  for RowIndex := 1 to sgBookedFlights.RowCount - 1 do
  begin
    if SameText(sgBookedFlights.Cells[COL_FLIGHTID, RowIndex], SearchID) then
    begin
      sgBookedFlights.Row := RowIndex;
      ShowMessage('Flight found at row ' + IntToStr(RowIndex));
      Exit;
    end;
  end;

  ShowMessage('FlightID not found.');
end;

procedure TfrmMyFlights.btnRemoveClick(Sender: TObject);
var
  SelectedRow: Integer;
  FlightID, UserID, FileName: string;
  SeatCount: Integer;
  PricePerSeat, TotalDeduct: Double;
  I: Integer;
begin
  SelectedRow := sgBookedFlights.Row;

  if SelectedRow <= 0 then
  begin
    ShowMessage('Please select a booking to remove.');
    Exit;
  end;

  // Gather values from the grid
  FlightID := sgBookedFlights.Cells[COL_FLIGHTID, SelectedRow];
  SeatCount := SafeStrToIntDef(sgBookedFlights.Cells[COL_SEATS,
    SelectedRow], 0);
  PricePerSeat := ParsePriceToFloat(sgBookedFlights.Cells[COL_PRICE_PER,
    SelectedRow]);
  TotalDeduct := SeatCount * PricePerSeat;

  // Store deleted row for UNDO
  for I := 0 to 6 do
    gLastDeletedRowData[I] := sgBookedFlights.Cells[I, SelectedRow];
  gLastDeletedRowIndex := SelectedRow;
  gUndoAvailable := True;

  // Remove from text file (7-line block)
  UserID := frmLoginRegister.sUserID;
  FileName := UserID + '_Booking.txt';
  if FileExists(FileName) then
    RemoveBookingFromFile(FileName, FlightID);

  // Update the user's totals in tblFlights (aggregate per user)
  with dmAccounts do
  begin
    qryFlights.Close;
    qryFlights.SQL.Text := 'SELECT * FROM tblFlights WHERE UserID = :UserID';
    qryFlights.Parameters.ParamByName('UserID').Value := UserID;
    qryFlights.Open;

    if not qryFlights.Eof then
    begin
      qryFlights.Edit;
      qryFlights.FieldByName('NOFlights').AsInteger :=
        Max(0, qryFlights.FieldByName('NOFlights').AsInteger - 1);

      qryFlights.FieldByName('NOSeats').AsInteger :=
        Max(0, qryFlights.FieldByName('NOSeats').AsInteger - SeatCount);

      qryFlights.FieldByName('TotalPrice').AsFloat :=
        qryFlights.FieldByName('TotalPrice').AsFloat - TotalDeduct;

      qryFlights.Post;
    end;
  end;

  // Refresh the screen (reload list + summary)
  FormShow(Self);
end;

procedure TfrmMyFlights.btnUndoClick(Sender: TObject);
var
  Col, I: Integer;
  UserID: string;
  SeatCount: Integer;
  PricePerSeat: Double;
begin
  if not gUndoAvailable then
  begin
    ShowMessage('No booking to undo.');
    Exit;
  end;

  // Put the row back into the grid at the original index
  sgBookedFlights.RowCount := sgBookedFlights.RowCount + 1;

  // Shift rows down to make space at gLastDeletedRowIndex
  for I := sgBookedFlights.RowCount - 1 downto gLastDeletedRowIndex + 1 do
    for Col := 0 to sgBookedFlights.ColCount - 1 do
      sgBookedFlights.Cells[Col, I] := sgBookedFlights.Cells[Col, I - 1];

  // Restore the deleted row values
  for Col := 0 to 6 do
    sgBookedFlights.Cells[Col, gLastDeletedRowIndex] :=
      gLastDeletedRowData[Col];

  // Update database totals back
  UserID := frmLoginRegister.sUserID;
  SeatCount := SafeStrToIntDef(gLastDeletedRowData[COL_SEATS], 0);
  PricePerSeat := ParsePriceToFloat(gLastDeletedRowData[COL_PRICE_PER]);

  with dmAccounts do
  begin
    qryFlights.Close;
    qryFlights.SQL.Text := 'SELECT * FROM tblFlights WHERE UserID = :UserID';
    qryFlights.Parameters.ParamByName('UserID').Value := UserID;
    qryFlights.Open;

    if not qryFlights.Eof then
    begin
      qryFlights.Edit;
      qryFlights.FieldByName('NOFlights').AsInteger :=
        qryFlights.FieldByName('NOFlights').AsInteger + 1;

      qryFlights.FieldByName('NOSeats').AsInteger :=
        qryFlights.FieldByName('NOSeats').AsInteger + SeatCount;

      qryFlights.FieldByName('TotalPrice').AsFloat :=
        qryFlights.FieldByName('TotalPrice').AsFloat +
        (SeatCount * PricePerSeat);

      qryFlights.Post;
    end;
  end;

  // Restore into file in the same 7-line format the loader expects
  RestoreBookingToFile(UserID);

  // Reload from file to ensure grid and file are perfectly in sync
  LoadBookingsFromFile(UserID + '_Booking.txt');
  RefreshSummaryMemo(UserID);

  // Undo finished
  gUndoAvailable := False;
  gLastDeletedRowIndex := -1;

  ShowMessage('Undo complete.');
end;

{ ============================ SCREEN POPULATION ============================ }

procedure TfrmMyFlights.FormShow(Sender: TObject);
var
  UserID, FullName, Src, Dst: string;
begin
  // Always start from a TEMP copy when viewing/editing
  UserID := frmLoginRegister.sUserID;
  Src := UserID + '_Booking.txt';
  Dst := UserID + '_Booking_TEMP.txt';

  if FileExists(Src) then
    Winapi.Windows.CopyFile(PChar(Src), PChar(Dst), False);

  // Grid: headers + clean slate
  SetupGridHeaders;
  ClearGridData;

  // Load into grid (TEMP file if exists, else original)
  if FileExists(Dst) then
    LoadBookingsFromFile(Dst)
  else if FileExists(Src) then
    LoadBookingsFromFile(Src)
  else
    ShowMessage('No bookings found for this user.');

  // Get full name for the summary
  with dmAccounts do
  begin
    qryAccounts.Close;
    qryAccounts.SQL.Text :=
      'SELECT Firstname, Lastname FROM tblAccounts WHERE UserID = :UserID';
    qryAccounts.Parameters.ParamByName('UserID').Value := UserID;
    qryAccounts.Open;

    if not qryAccounts.Eof then
      FullName := qryAccounts.FieldByName('Firstname').AsString + ' ' +
        qryAccounts.FieldByName('Lastname').AsString
    else
      FullName := 'Unknown User';
  end;

  // Show totals summary
  RefreshSummaryMemo(FullName);
end;

procedure TfrmMyFlights.RefreshSummaryMemo(const FullName: string);
begin
  with dmAccounts do
  begin
    qryFlights.Close;
    qryFlights.SQL.Text := 'SELECT * FROM tblFlights WHERE UserID = :UserID';
    qryFlights.Parameters.ParamByName('UserID').Value :=
      frmLoginRegister.sUserID;
    qryFlights.Open;

    memFlightDetails.Clear;
    if not qryFlights.Eof then
    begin
      memFlightDetails.Lines.Add('Flight Summary for: ' + FullName);
      memFlightDetails.Lines.Add('------------------------------');
      memFlightDetails.Lines.Add('Total Flights: ' + qryFlights.FieldByName
        ('NOFlights').AsString);
      memFlightDetails.Lines.Add('Total Seats: ' + qryFlights.FieldByName
        ('NOSeats').AsString);
      memFlightDetails.Lines.Add('Total Price: R' + FormatFloat('0.00',
        qryFlights.FieldByName('TotalPrice').AsFloat));
      memFlightDetails.Lines.Add('------------------------------');
    end
    else
    begin
      memFlightDetails.Lines.Add('No summary data found for ' + FullName);
    end;
  end;
end;

{ ============================ FILE I/O ============================ }

procedure TfrmMyFlights.LoadBookingsFromFile(const FileName: string);
{
  Expected 7-line block per booking, in this order:
  FlightID: XXXXX
  From: Cape Town
  To: Johannesburg
  Class: Economy
  Seats: 2
  Price per seat: R1234.56
  Departure Date: 8/17/2025

  The loader will scan line-by-line and pick values based on the keys.
  It ignores any unexpected lines (so separators won't break it).
}
var
  Lines: TStringList;
  I, Row: Integer;
  L: string;
  Temp: array [0 .. 6] of string;
  HaveAnyField: Boolean;
begin
  if not FileExists(FileName) then
    Exit;

  Lines := TStringList.Create;
  try
    Lines.LoadFromFile(FileName);

    // Start clean (but keep headers)
    sgBookedFlights.RowCount := 1; // header only
    Row := 0; // will increment before writing a data row

    // Reset temp fields
    FillChar(Temp, SizeOf(Temp), 0);

    HaveAnyField := False;

    I := 0;
    while I < Lines.Count do
    begin
      L := Trim(Lines[I]);

      if StartsWith(L, 'FlightID:') then
      begin
        // If we already captured a previous record, commit it before starting new one
        if HaveAnyField then
        begin
          sgBookedFlights.RowCount := sgBookedFlights.RowCount + 1;
          Row := sgBookedFlights.RowCount - 1;
          sgBookedFlights.Cells[COL_FLIGHTID, Row] := Temp[COL_FLIGHTID];
          sgBookedFlights.Cells[COL_FROM, Row] := Temp[COL_FROM];
          sgBookedFlights.Cells[COL_TO, Row] := Temp[COL_TO];
          sgBookedFlights.Cells[COL_CLASS, Row] := Temp[COL_CLASS];
          sgBookedFlights.Cells[COL_SEATS, Row] := Temp[COL_SEATS];
          sgBookedFlights.Cells[COL_PRICE_PER, Row] := Temp[COL_PRICE_PER];
          sgBookedFlights.Cells[COL_DEPARTUREDATE, Row] :=
            Temp[COL_DEPARTUREDATE];

          // Reset temp for next record
          FillChar(Temp, SizeOf(Temp), 0);
          HaveAnyField := False;
        end;

        Temp[COL_FLIGHTID] := ExtractValueAfterColon(L);
        HaveAnyField := True;
      end
      else if StartsWith(L, 'From:') then
      begin
        Temp[COL_FROM] := ExtractValueAfterColon(L);
        HaveAnyField := True;
      end
      else if StartsWith(L, 'To:') then
      begin
        Temp[COL_TO] := ExtractValueAfterColon(L);
        HaveAnyField := True;
      end
      else if StartsWith(L, 'Class:') then
      begin
        Temp[COL_CLASS] := ExtractValueAfterColon(L);
        HaveAnyField := True;
      end
      else if StartsWith(L, 'Seats:') then
      begin
        Temp[COL_SEATS] := ExtractValueAfterColon(L);
        HaveAnyField := True;
      end
      else if StartsWith(L, 'Price per seat:') then
      begin
        Temp[COL_PRICE_PER] := ExtractValueAfterColon(L);
        HaveAnyField := True;
      end
      else if StartsWith(L, 'Departure Date:') then
      begin
        Temp[COL_DEPARTUREDATE] := ExtractValueAfterColon(L);
        HaveAnyField := True;

        // We have the last field of a full record -> commit the record now
        sgBookedFlights.RowCount := sgBookedFlights.RowCount + 1;
        Row := sgBookedFlights.RowCount - 1;
        sgBookedFlights.Cells[COL_FLIGHTID, Row] := Temp[COL_FLIGHTID];
        sgBookedFlights.Cells[COL_FROM, Row] := Temp[COL_FROM];
        sgBookedFlights.Cells[COL_TO, Row] := Temp[COL_TO];
        sgBookedFlights.Cells[COL_CLASS, Row] := Temp[COL_CLASS];
        sgBookedFlights.Cells[COL_SEATS, Row] := Temp[COL_SEATS];
        sgBookedFlights.Cells[COL_PRICE_PER, Row] := Temp[COL_PRICE_PER];
        sgBookedFlights.Cells[COL_DEPARTUREDATE, Row] :=
          Temp[COL_DEPARTUREDATE];

        // Reset for next potential record
        FillChar(Temp, SizeOf(Temp), 0);
        HaveAnyField := False;
      end;

      Inc(I);
    end;

    // If the file ended mid-record (missing last line), still commit what we have
    if HaveAnyField then
    begin
      sgBookedFlights.RowCount := sgBookedFlights.RowCount + 1;
      Row := sgBookedFlights.RowCount - 1;
      sgBookedFlights.Cells[COL_FLIGHTID, Row] := Temp[COL_FLIGHTID];
      sgBookedFlights.Cells[COL_FROM, Row] := Temp[COL_FROM];
      sgBookedFlights.Cells[COL_TO, Row] := Temp[COL_TO];
      sgBookedFlights.Cells[COL_CLASS, Row] := Temp[COL_CLASS];
      sgBookedFlights.Cells[COL_SEATS, Row] := Temp[COL_SEATS];
      sgBookedFlights.Cells[COL_PRICE_PER, Row] := Temp[COL_PRICE_PER];
      sgBookedFlights.Cells[COL_DEPARTUREDATE, Row] := Temp[COL_DEPARTUREDATE];
    end;

    // Make sure there is at least 1 data row visible
    if sgBookedFlights.RowCount < 2 then
      sgBookedFlights.RowCount := 2;

    FormatGridColumns;
  finally
    Lines.Free;
  end;
end;

procedure TfrmMyFlights.RemoveBookingFromFile(const FileName,
  TargetFlightID: string);
{
  Removes the 7-line block that starts with "FlightID: TargetFlightID".
  If separators or extra lines exist, they are preserved (we only remove the known 7 lines).
}
var
  Lines: TStringList;
  I: Integer;
  Line: string;
begin
  if not FileExists(FileName) then
    Exit;

  Lines := TStringList.Create;
  try
    Lines.LoadFromFile(FileName);

    I := 0;
    while I < Lines.Count do
    begin
      Line := Trim(Lines[I]);

      if StartsWith(Line, 'FlightID:') and
        (ExtractValueAfterColon(Line) = TargetFlightID) then
      begin
        // Remove 7 standard lines if present
        // (If file has extra separators, we leave them alone.)
        // Guard against running past end of list.
        if I + 6 < Lines.Count then
        begin
          Lines.Delete(I); // FlightID
          Lines.Delete(I); // From
          Lines.Delete(I); // To
          Lines.Delete(I); // Class
          Lines.Delete(I); // Seats
          Lines.Delete(I); // Price per seat
          Lines.Delete(I); // Departure Date
        end
        else
        begin
          // If the file somehow ends unexpectedly, remove what we can
          while (I < Lines.Count) and
            (not StartsWith(Trim(Lines[I]), 'FlightID:')) do
            Lines.Delete(I);
          if (I < Lines.Count) then
            Lines.Delete(I); // remove the partial FlightID line
        end;

        Break; // only remove first matching block
      end
      else
        Inc(I);
    end;

    Lines.SaveToFile(FileName);
  finally
    Lines.Free;
  end;
end;

procedure TfrmMyFlights.RestoreBookingToFile(const UserID: string);
{
  Appends a booking (7 lines) back into the user's main booking file.
  Must match the format that LoadBookingsFromFile expects.
}
var
  Lines: TStringList;
  FileName: string;
begin
  FileName := UserID + '_Booking.txt';

  Lines := TStringList.Create;
  try
    if FileExists(FileName) then
      Lines.LoadFromFile(FileName);

    Lines.Add('FlightID: ' + gLastDeletedRowData[COL_FLIGHTID]);
    Lines.Add('From: ' + gLastDeletedRowData[COL_FROM]);
    Lines.Add('To: ' + gLastDeletedRowData[COL_TO]);
    Lines.Add('Class: ' + gLastDeletedRowData[COL_CLASS]);
    Lines.Add('Seats: ' + gLastDeletedRowData[COL_SEATS]);
    Lines.Add('Price per seat: ' + gLastDeletedRowData[COL_PRICE_PER]);
    Lines.Add('Departure Date: ' + gLastDeletedRowData[COL_DEPARTUREDATE]);

    Lines.SaveToFile(FileName);
  finally
    Lines.Free;
  end;
end;

end.
