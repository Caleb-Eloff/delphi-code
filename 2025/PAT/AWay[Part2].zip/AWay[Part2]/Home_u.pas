unit Home_u;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls, Vcl.StdCtrls,
  dmAccounts_u;

type
  TfrmHome = class(TForm)
    imgHomeBackground: TImage;
    btnHomeBookFlights: TButton;
    btnHomeMyFlights: TButton;
    btnHomeProfile: TButton;
    lblHomeHeading1: TLabel;
    btnHomeLogOut: TButton;
    lblHomeHeading2: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure btnHomeLogOutClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure btnHomeBookFlightsClick(Sender: TObject);
    procedure btnHomeMyFlightsClick(Sender: TObject);
    procedure btnHomeProfileClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    sUserID: String;

  end;

var
  frmHome: TfrmHome;

implementation

{$R *.dfm}

uses LoginRegister_u, BookFlights_u, MyFlights_u, Profile_u;

procedure TfrmHome.btnHomeBookFlightsClick(Sender: TObject);
begin

  frmHome.Hide;
  frmBookFlights.Show;

end;

procedure TfrmHome.btnHomeLogOutClick(Sender: TObject);
begin

  frmHome.Hide;
  frmLoginRegister.Show;

end;

procedure TfrmHome.btnHomeMyFlightsClick(Sender: TObject);
begin

  frmHome.Hide;
  frmMyFlights.Show;

end;

procedure TfrmHome.btnHomeProfileClick(Sender: TObject);
begin

  frmHome.Hide;
  frmProfile.Show;

end;

procedure TfrmHome.FormClose(Sender: TObject; var Action: TCloseAction);
begin

  Application.Terminate;

end;

procedure TfrmHome.FormCreate(Sender: TObject);
begin

  // Remove title bar and borders
  BorderStyle := bsNone;

  // Maximize to full screen
  SetBounds(0, 0, Screen.Width, Screen.Height);
  // Set Boundaries for screen dimensions
  WindowState := wsMaximized;

  // Load background image
  imgHomeBackground.Picture.LoadFromFile('Background.png');

  // Align Form's buttons
  btnHomeBookFlights.Left := (frmHome.Width - btnHomeBookFlights.Width) DIV 2;
  btnHomeMyFlights.Left := (frmHome.Width - btnHomeMyFlights.Width) DIV 2;
  btnHomeProfile.Left := (frmHome.Width - btnHomeProfile.Width) DIV 2;

  btnHomeLogOut.Top := (frmHome.Height - btnHomeLogOut.Height) DIV 100 * 99;

end;

procedure TfrmHome.FormShow(Sender: TObject);
begin

  // Heading setup
  lblHomeHeading1.Caption := 'Welcome, ' + frmLoginRegister.sUsername + ' to';
  lblHomeHeading2.Caption := 'A-Way Airlines!';

  // Align Form's labels
  lblHomeHeading1.Left := (frmHome.Width - lblHomeHeading1.Width) DIV 2;
  lblHomeHeading2.Left := (frmHome.Width - lblHomeHeading2.Width) DIV 2;

end;

end.
