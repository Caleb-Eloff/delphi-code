﻿unit BookFlights_u;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls, Vcl.StdCtrls,
  Vcl.ComCtrls, Math, Vcl.Grids, Vcl.Samples.Spin, dmAccounts_u;

type
  TfrmBookFlights = class(TForm)
    imgBookFlightsBackground: TImage;
    pnlContinents: TPanel;
    imgContinents: TImage;
    lblNorthAmerica: TLabel;
    lblSouthAmerica: TLabel;
    lblAfrica: TLabel;
    lblEurope: TLabel;
    lblAsia: TLabel;
    lblAustralia: TLabel;
    pnlNorthAmerica: TPanel;
    imgNorthAmerica: TImage;
    pnlSouthAmerica: TPanel;
    imgSouthAmerica: TImage;
    pnlAfrica: TPanel;
    imgAfrica: TImage;
    pnlEurope: TPanel;
    imgEurope: TImage;
    pnlAsia: TPanel;
    imgAsia: TImage;
    pnlAustralia: TPanel;
    imgAustralia: TImage;
    lblUS: TLabel;
    lblCanada: TLabel;
    lblUnitedStates: TLabel;
    lblMexico: TLabel;
    pnlDestination: TPanel;
    btnBookFlightsBack: TButton;
    imgDestinationBackground: TImage;
    lblColombia: TLabel;
    lblVenezuela: TLabel;
    lblGuyana: TLabel;
    lblSuriname: TLabel;
    lblGuina: TLabel;
    lblBrazil: TLabel;
    lblBolivia: TLabel;
    lblArgentina: TLabel;
    lblParaguay: TLabel;
    lblUruguay: TLabel;
    lblChile: TLabel;
    lblPeru: TLabel;
    lblEcuador: TLabel;
    lblAlgeria: TLabel;
    lblMauritania: TLabel;
    lblSenegal: TLabel;
    lblGuinea: TLabel;
    lblMali: TLabel;
    lblBurkinaFaso: TLabel;
    lblGhana: TLabel;
    lblNiger: TLabel;
    lblLibya: TLabel;
    lblEgypt: TLabel;
    lblSudan: TLabel;
    lblEthiopia: TLabel;
    lblKenya: TLabel;
    lblChad: TLabel;
    lblNigeria: TLabel;
    lblCameroon: TLabel;
    lblGabon: TLabel;
    lblDemocraticRepublicCongo: TLabel;
    lblTanzania: TLabel;
    lblMozambique: TLabel;
    lblZambia: TLabel;
    lblAngola: TLabel;
    lblNamibia: TLabel;
    lblBotswana: TLabel;
    lblZimbabwe: TLabel;
    lblSouthAfrica: TLabel;
    lblIceland: TLabel;
    lblIreland: TLabel;
    lblUnitedKingdom: TLabel;
    lblNorway: TLabel;
    lblSweden: TLabel;
    lblFinland: TLabel;
    lblRussia: TLabel;
    lblPortugal: TLabel;
    lblSpain: TLabel;
    lblFrance: TLabel;
    lblUkraine: TLabel;
    lblGermany: TLabel;
    lblPoland: TLabel;
    lblRomania: TLabel;
    lblLithuania: TLabel;
    lblBelarus: TLabel;
    lblTurkey: TLabel;
    lblItaly: TLabel;
    lblBulgaria: TLabel;
    lblHungary: TLabel;
    lblGreece: TLabel;
    lblAustralia2: TLabel;
    lblRussia2: TLabel;
    lblJapan: TLabel;
    lblChina: TLabel;
    lblIndia: TLabel;
    lblKazakhstan: TLabel;
    lblPakistan: TLabel;
    lblIran: TLabel;
    lblThailand: TLabel;
    lblSingapore: TLabel;
    lblMongolia: TLabel;
    lblDestinationHeading: TLabel;
    cmbDestinationFrom: TComboBox;
    lblDestinationFrom: TLabel;
    lblDestinationTo: TLabel;
    cmbDestinationTo: TComboBox;
    dtpDate: TDateTimePicker;
    lblAvailable: TLabel;
    btnDestinationDetailsConfirm: TButton;
    btnDestinationChooseFlight: TButton;
    sgAvailableFlights: TStringGrid;
    pnlFlightDetails: TPanel;
    lblFlightDetailsHeading: TLabel;
    memFlightDetails: TMemo;
    imgFlightDetailsBackground: TImage;
    rgClasses: TRadioGroup;
    spnSeats: TSpinEdit;
    lblNumberOfSeats: TLabel;
    btnFlightDetailsConfirm: TButton;
    memFlightDetailsFinal: TMemo;
    btnFlightDetailsFinalize: TButton;
    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure lblNorthAmericaClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure lblSouthAmericaClick(Sender: TObject);
    procedure lblAfricaClick(Sender: TObject);
    procedure lblEuropeClick(Sender: TObject);
    procedure lblAsiaClick(Sender: TObject);
    procedure lblAustraliaClick(Sender: TObject);
    procedure btnBookFlightsBackClick(Sender: TObject);
    procedure lblAlgeriaClick(Sender: TObject);
    procedure SelectCountryFromLabel(Sender: TObject);
    procedure lblAngolaClick(Sender: TObject);
    procedure lblBotswanaClick(Sender: TObject);
    procedure lblBurkinaFasoClick(Sender: TObject);
    procedure lblCameroonClick(Sender: TObject);
    procedure lblChadClick(Sender: TObject);
    procedure lblDemocraticRepublicCongoClick(Sender: TObject);
    procedure lblEgyptClick(Sender: TObject);
    procedure lblEthiopiaClick(Sender: TObject);
    procedure lblGabonClick(Sender: TObject);
    procedure lblGhanaClick(Sender: TObject);
    procedure lblGuineaClick(Sender: TObject);
    procedure lblKenyaClick(Sender: TObject);
    procedure lblLibyaClick(Sender: TObject);
    procedure lblMaliClick(Sender: TObject);
    procedure lblMauritaniaClick(Sender: TObject);
    procedure lblMozambiqueClick(Sender: TObject);
    procedure lblNamibiaClick(Sender: TObject);
    procedure lblNigerClick(Sender: TObject);
    procedure lblNigeriaClick(Sender: TObject);
    procedure lblSenegalClick(Sender: TObject);
    procedure lblSouthAfricaClick(Sender: TObject);
    procedure lblSudanClick(Sender: TObject);
    procedure lblTanzaniaClick(Sender: TObject);
    procedure lblZambiaClick(Sender: TObject);
    procedure lblZimbabweClick(Sender: TObject);
    procedure lblChinaClick(Sender: TObject);
    procedure lblIndiaClick(Sender: TObject);
    procedure lblIranClick(Sender: TObject);
    procedure lblJapanClick(Sender: TObject);
    procedure lblKazakhstanClick(Sender: TObject);
    procedure lblMongoliaClick(Sender: TObject);
    procedure lblPakistanClick(Sender: TObject);
    procedure lblSingaporeClick(Sender: TObject);
    procedure lblThailandClick(Sender: TObject);
    procedure lblAustralia2Click(Sender: TObject);
    procedure lblBelarusClick(Sender: TObject);
    procedure lblBulgariaClick(Sender: TObject);
    procedure lblFinlandClick(Sender: TObject);
    procedure lblFranceClick(Sender: TObject);
    procedure lblGermanyClick(Sender: TObject);
    procedure lblGreeceClick(Sender: TObject);
    procedure lblHungaryClick(Sender: TObject);
    procedure lblIcelandClick(Sender: TObject);
    procedure lblIrelandClick(Sender: TObject);
    procedure lblItalyClick(Sender: TObject);
    procedure lblLithuaniaClick(Sender: TObject);
    procedure lblNorwayClick(Sender: TObject);
    procedure lblPolandClick(Sender: TObject);
    procedure lblPortugalClick(Sender: TObject);
    procedure lblRomaniaClick(Sender: TObject);
    procedure lblRussiaClick(Sender: TObject);
    procedure lblSpainClick(Sender: TObject);
    procedure lblSwedenClick(Sender: TObject);
    procedure lblTurkeyClick(Sender: TObject);
    procedure lblUkraineClick(Sender: TObject);
    procedure lblUnitedKingdomClick(Sender: TObject);
    procedure lblCanadaClick(Sender: TObject);
    procedure lblMexicoClick(Sender: TObject);
    procedure lblUnitedStatesClick(Sender: TObject);
    procedure lblUSClick(Sender: TObject);
    procedure lblArgentinaClick(Sender: TObject);
    procedure lblBoliviaClick(Sender: TObject);
    procedure lblBrazilClick(Sender: TObject);
    procedure lblChileClick(Sender: TObject);
    procedure lblColombiaClick(Sender: TObject);
    procedure lblEcuadorClick(Sender: TObject);
    procedure lblGuinaClick(Sender: TObject);
    procedure lblGuyanaClick(Sender: TObject);
    procedure lblParaguayClick(Sender: TObject);
    procedure lblPeruClick(Sender: TObject);
    procedure lblSurinameClick(Sender: TObject);
    procedure lblUruguayClick(Sender: TObject);
    procedure lblVenezuelaClick(Sender: TObject);
    procedure btnDestinationDetailsConfirmClick(Sender: TObject);
    function CalculateDistance(lbl1, lbl2: TLabel): Double;
    function GetLabelByDestination(const destination: string): TLabel;
    procedure GenerateFlightOptions(basePrice: Double);
    procedure lblRussia2Click(Sender: TObject);
    procedure btnDestinationChooseFlightClick(Sender: TObject);
    procedure SetupAvailableFlightsGrid;
    procedure rgClassesClick(Sender: TObject);
    procedure btnFlightDetailsConfirmClick(Sender: TObject);
    procedure btnFlightDetailsFinalizeClick(Sender: TObject);
    function GenerateUnqiueFlightNumber(existingList: TStringList): string;
  private
    dBasePrice: Double;
    dMultiplier: Double;
    bBookingConfirmed: Boolean;
    gridFlightNum: String;

  public
    { Public declarations }
    pricePerPixel: Real;
  end;

var
  frmBookFlights: TfrmBookFlights;

implementation

{$R *.dfm}

uses Home_u, LoginRegister_u;

procedure TfrmBookFlights.btnBookFlightsBackClick(Sender: TObject);
begin

  if (pnlContinents.Visible = False) then
  begin

    imgContinents.Visible := True;
    pnlNorthAmerica.Hide;
    pnlSouthAmerica.Hide;
    pnlAfrica.Hide;
    pnlEurope.Hide;
    pnlAsia.Hide;
    pnlAustralia.Hide;
    pnlContinents.Show;

  end
  else if (pnlContinents.Visible = True) then
  begin

    frmBookFlights.Hide;
    frmHome.Show;

  end;

end;

procedure TfrmBookFlights.btnDestinationChooseFlightClick(Sender: TObject);
var
  flightNumInput, airline, price: string;
  row: Integer;
  found: Boolean;

begin
  flightNumInput := Trim(InputBox('Choose Flight', 'Enter Flight Number:', ''));

  // Basic validation
  if flightNumInput = '' then
  begin
    ShowMessage('Please enter a flight number.');
    Exit;
  end;

  if not flightNumInput.StartsWith('FL') then
  begin
    ShowMessage('Flight number must start with "FL".');
    Exit;
  end;

  found := False;

  for row := 1 to sgAvailableFlights.RowCount - 1 do
  begin
    gridFlightNum := sgAvailableFlights.Cells[1, row]; // Column 1 = FlightNo

    if SameText(gridFlightNum, flightNumInput) then
    begin
      airline := sgAvailableFlights.Cells[0, row];
      price := sgAvailableFlights.Cells[2, row];

      // Format memo output
      memFlightDetails.Clear;
      memFlightDetails.Lines.Add('==============================');
      memFlightDetails.Lines.Add('        FLIGHT DETAILS        ');
      memFlightDetails.Lines.Add('==============================');
      memFlightDetails.Lines.Add(Format('%-15s %s', ['Airline:', airline]));
      memFlightDetails.Lines.Add(Format('%-15s %s', ['Flight Number:',
        gridFlightNum]));
      memFlightDetails.Lines.Add(Format('%-15s %s', ['Price:', price]));
      memFlightDetails.Lines.Add('==============================');

      SetupAvailableFlightsGrid;

      pnlFlightDetails.Show;
      pnlDestination.Hide;
      found := True;
      Break;
    end;
  end;

  if not found then
    ShowMessage('Flight number "' + flightNumInput + '" not found.');
end;

procedure TfrmBookFlights.btnDestinationDetailsConfirmClick(Sender: TObject);
var
  lblFrom, lblTo: TLabel;
  distance, totalPrice: Double;
  flightList: TStringList;
  parts: TArray<string>;
  airline, flightNum, price: string;
  i: Integer;

begin
  // Basic validation
  if (cmbDestinationFrom.ItemIndex = -1) or (cmbDestinationTo.ItemIndex = -1)
  then
  begin
    ShowMessage('Please select both "From" and "To" destinations.');
    Exit;
  end;

  if cmbDestinationFrom.Text = cmbDestinationTo.Text then
  begin
    ShowMessage('"From" and "To" destinations cannot be the same.');
    Exit;
  end;

  // Date validation
  if dtpDate.Date < Date then
  begin
    ShowMessage('Departure date cannot be in the past.');
    Exit;
  end;

  // Get labels
  lblFrom := GetLabelByDestination(cmbDestinationFrom.Text);
  lblTo := GetLabelByDestination(cmbDestinationTo.Text);
  if (lblFrom = nil) or (lblTo = nil) then
  begin
    ShowMessage('Invalid destination labels.');
    Exit;
  end;

  // Calculate price
  distance := CalculateDistance(lblFrom, lblTo);
  totalPrice := distance * pricePerPixel;

  ShowMessage(Format('Estimated flight cost from %s to %s is R%.2f',
    [cmbDestinationFrom.Text, cmbDestinationTo.Text, totalPrice]));

  // Generate and load flights
  GenerateFlightOptions(totalPrice);

  flightList := TStringList.Create;
  try
    flightList.LoadFromFile('tempFlights.txt');

    sgAvailableFlights.RowCount := Max(2, flightList.Count + 1);

    sgAvailableFlights.Cells[0, 0] := 'Airline';
    sgAvailableFlights.Cells[1, 0] := 'FlightNo';
    sgAvailableFlights.Cells[2, 0] := 'Price';

    for i := 0 to flightList.Count - 1 do
    begin
      parts := flightList[i].Split(['%']);
      if Length(parts) = 2 then
      begin
        airline := Trim(Copy(parts[0], 1, Pos('FL', parts[0]) - 1));
        flightNum := Trim(Copy(parts[0], Pos('FL', parts[0]), MaxInt));
        price := parts[1];

        sgAvailableFlights.Cells[0, i + 1] := airline;
        sgAvailableFlights.Cells[1, i + 1] := flightNum;
        sgAvailableFlights.Cells[2, i + 1] := 'R' + price;
      end;
    end;
  finally
    flightList.Free;
  end;

  SetupAvailableFlightsGrid;

  dBasePrice := StrToFloat(price);
end;

procedure TfrmBookFlights.btnFlightDetailsConfirmClick(Sender: TObject);
var
  seatCount: Integer;
  finalPrice: Double;
  selectedClass: string;
begin
  // Validate destinations
  if (cmbDestinationFrom.ItemIndex = -1) or (cmbDestinationTo.ItemIndex = -1)
  then
  begin
    ShowMessage('Please select both "From" and "To" destinations.');
    Exit;
  end;

  if cmbDestinationFrom.Text = cmbDestinationTo.Text then
  begin
    ShowMessage('"From" and "To" destinations cannot be the same.');
    Exit;
  end;

  // Validate class selection
  if rgClasses.ItemIndex = -1 then
  begin
    ShowMessage('Please select a flight class.');
    Exit;
  end;

  // Validate seat count
  seatCount := spnSeats.Value;
  if seatCount < 1 then
  begin
    ShowMessage('Please select at least one seat.');
    Exit;
  end;

  // Optional: Validate pricing inputs
  if (dBasePrice <= 0) or (dMultiplier <= 0) then
  begin
    ShowMessage('Invalid pricing data. Please reselect your flight.');
    Exit;
  end;

  // Calculate final price
  finalPrice := dBasePrice * dMultiplier * seatCount;
  selectedClass := rgClasses.Items[rgClasses.ItemIndex];

  // Format memo output
  memFlightDetailsFinal.Lines.Clear;
  memFlightDetailsFinal.Lines.Add('==============================');
  memFlightDetailsFinal.Lines.Add('      CONFIRMED BOOKING       ');
  memFlightDetailsFinal.Lines.Add('==============================');
  memFlightDetailsFinal.Lines.Add(Format('%-15s %s',
    ['From:', cmbDestinationFrom.Text]));
  memFlightDetailsFinal.Lines.Add(Format('%-15s %s',
    ['To:', cmbDestinationTo.Text]));
  memFlightDetailsFinal.Lines.Add(Format('%-15s %s',
    ['Class:', selectedClass]));
  memFlightDetailsFinal.Lines.Add(Format('%-15s %d', ['Seats:', seatCount]));
  memFlightDetailsFinal.Lines.Add(Format('%-15s R%.2f',
    ['Total Price:', finalPrice]));
  memFlightDetailsFinal.Lines.Add('==============================');

  bBookingConfirmed := True;

end;

procedure TfrmBookFlights.btnFlightDetailsFinalizeClick(Sender: TObject);
var
  numberOfSeats: Integer;
  priceEachSeat, totalCost: Double;
  flightClass, fileName, userName, bookingInfo: string;
  todayDate, flightDate: TDateTime;
  bookingFile: TextFile;
begin
  // Check if the user picked places to fly from and to
  if (cmbDestinationFrom.ItemIndex = -1) or (cmbDestinationTo.ItemIndex = -1)
  then
  begin
    ShowMessage('Please choose where you are flying from and to.');
    Exit;
  end;

  // Make sure the user isn’t flying to the same place they’re leaving from
  if cmbDestinationFrom.Text = cmbDestinationTo.Text then
  begin
    ShowMessage('You can’t fly to the same place you’re leaving from.');
    Exit;
  end;

  // Check if the user picked a flight class
  if rgClasses.ItemIndex = -1 then
  begin
    ShowMessage('Please choose a flight class.');
    Exit;
  end;

  // Get how many seats the user wants
  numberOfSeats := spnSeats.Value;
  if numberOfSeats < 1 then
  begin
    ShowMessage('You need to book at least one seat.');
    Exit;
  end;

  // Make sure the user clicked “Confirm Booking” before finalizing
  if not bBookingConfirmed then
  begin
    ShowMessage('Please confirm your booking first.');
    Exit;
  end;

  // Calculate the cost
  priceEachSeat := dBasePrice * dMultiplier;
  totalCost := priceEachSeat * numberOfSeats;
  flightClass := rgClasses.Items[rgClasses.ItemIndex];
  todayDate := Now;
  flightDate := dtpDate.Date;
  userName := frmLoginRegister.sUserID;

  // Update the database with the new booking
  with dmAccounts do
  begin
    qryFlights.Close;
    qryFlights.SQL.Text := 'SELECT * FROM tblFlights WHERE UserID = :UserID';
    qryFlights.Parameters.ParamByName('UserID').Value := userName;
    qryFlights.Open;

    if not qryFlights.Eof then
    begin
      // Add to the user's totals
      qryFlights.Edit;
      qryFlights.FieldByName('NOFlights').AsInteger :=
        qryFlights.FieldByName('NOFlights').AsInteger + 1;
      qryFlights.FieldByName('NOSeats').AsInteger :=
        qryFlights.FieldByName('NOSeats').AsInteger + numberOfSeats;
      qryFlights.FieldByName('TotalPrice').AsFloat :=
        qryFlights.FieldByName('TotalPrice').AsFloat + totalCost;
      qryFlights.Post;
    end
    else
    begin
      // Add a new record for this user
      qryFlights.Close;
      qryFlights.SQL.Text :=
        'INSERT INTO tblFlights (UserID, NOFlights, NOSeats, TotalPrice) ' +
        'VALUES (:UserID, :NOFlights, :NOSeats, :TotalPrice)';
      qryFlights.Parameters.ParamByName('UserID').Value := userName;
      qryFlights.Parameters.ParamByName('NOFlights').Value := 1;
      qryFlights.Parameters.ParamByName('NOSeats').Value := numberOfSeats;
      qryFlights.Parameters.ParamByName('TotalPrice').Value := totalCost;
      qryFlights.ExecSQL;
    end;
  end;

  // Prepare the booking info
  fileName := userName + '_Booking.txt';
  bookingInfo := '==============================' + sLineBreak + 'Booking for: '
    + userName + sLineBreak + 'FlightID: ' + gridFlightNum + sLineBreak +
  // ← Add this line
    'From: ' + cmbDestinationFrom.Text + sLineBreak + 'To: ' +
    cmbDestinationTo.Text + sLineBreak + 'Class: ' + flightClass + sLineBreak +
    'Seats: ' + IntToStr(numberOfSeats) + sLineBreak + 'Price per seat: R' +
    FormatFloat('0.00', priceEachSeat) + sLineBreak + 'Departure Date: ' +
    DateToStr(flightDate) + sLineBreak + 'Booking Date: ' + DateToStr(todayDate)
    + sLineBreak + '==============================' + sLineBreak + sLineBreak;

  // Write the booking info into a text file (beginner-friendly method)
  AssignFile(bookingFile, fileName);
  if FileExists(fileName) then
    Append(bookingFile)
  else
    Rewrite(bookingFile);

  WriteLn(bookingFile, bookingInfo);
  CloseFile(bookingFile);

  // Show a message and go back to the home screen
  ShowMessage('Your flight is booked and saved!');
  frmBookFlights.Hide;
  frmHome.Show;
end;

function TfrmBookFlights.CalculateDistance(lbl1, lbl2: TLabel): Double;
var
  iDistanceX, iDistanceY: Integer;

begin

  iDistanceX := lbl2.Left - lbl1.Left;
  iDistanceY := lbl2.Top - lbl1.Top;
  Result := Sqrt(Sqr(iDistanceX) + Sqr(iDistanceY)); // It's Pythagoras!!!

end;

procedure TfrmBookFlights.FormClose(Sender: TObject; var Action: TCloseAction);
begin

  Application.Terminate;

end;

procedure TfrmBookFlights.FormCreate(Sender: TObject);
var
  CountriesFile: TextFile;
  i, iColWidth: Integer;

begin

  pricePerPixel := 7.5;

  // Remove title bar and borders
  BorderStyle := bsNone;

  // Maximize to full screen
  SetBounds(0, 0, Screen.Width, Screen.Height);
  // Set Boundaries for screen dimensions
  WindowState := wsMaximized;

  // Load background image
  imgBookFlightsBackground.Picture.LoadFromFile('Background.png');
  imgDestinationBackground.Picture.LoadFromFile('DestinationBackground.png');
  imgFlightDetailsBackground.Picture.LoadFromFile('DestinationBackground.png');

  // Panels
  imgContinents.Picture.LoadFromFile('Continents.png');
  imgNorthAmerica.Picture.LoadFromFile('NorthAmerica.png');
  imgSouthAmerica.Picture.LoadFromFile('SouthAmerica.png');
  imgAfrica.Picture.LoadFromFile('Africa.jpg');
  imgEurope.Picture.LoadFromFile('Europe.png');
  imgAsia.Picture.LoadFromFile('Asia.png');
  imgAustralia.Picture.LoadFromFile('Australia.png');

  // Load combo boxes
  AssignFile(CountriesFile, 'Countries.txt');

  if FileExists('Countries.txt') then
  begin
    cmbDestinationFrom.Items.LoadFromFile('Countries.txt');
    cmbDestinationTo.Items.LoadFromFile('Countries.txt');
  end
  else
    ShowMessage('Countries.txt not found.');

  // Setup TStringGrid
  SetupAvailableFlightsGrid;

end;

procedure TfrmBookFlights.FormShow(Sender: TObject);
begin

  Randomize;

  bBookingConfirmed := False;

  pnlContinents.Show;
  pnlDestination.Show;

  pnlNorthAmerica.Hide;
  pnlSouthAmerica.Hide;
  pnlAfrica.Hide;
  pnlEurope.Hide;
  pnlAsia.Hide;
  pnlAustralia.Hide;
  pnlFlightDetails.Hide;

end;

procedure TfrmBookFlights.GenerateFlightOptions(basePrice: Double);
const
  AirplaneNames: array [0 .. 29] of string = ('SkyJet', 'AirNova',
    'CloudRunner', 'JetStream', 'FalconAir', 'NimbusFly', 'AeroSwift',
    'StarFlight', 'BlueHawk', 'SunWings', 'EagleJet', 'CometAir', 'OrbitFly',
    'ZenithAir', 'TurboSky', 'SkyPulse', 'AirQuest', 'NovaJet', 'JetNova',
    'SkyCruiser', 'CloudXpress', 'AirBolt', 'JetFusion', 'SkyLoom', 'NimbusOne',
    'AeroLink', 'StarJet', 'BlueNova', 'SunBird', 'FalconX');
var
  TempFile: TextFile;
  i: Integer;
  dVariedPrice: Double;
  tempFileName, line, flightCode: string;
  usedCodes: TStringList;

  function GenerateUniqueFlightCode(existing: TStringList): string;
  var
    code: string;
  begin
    repeat
      code := 'FL' + Chr(65 + Random(26)) + Chr(65 + Random(26)) +
        IntToStr(1000 + Random(9000));
    until existing.IndexOf(code) = -1;
    existing.Add(code);
    Result := code;
  end;

begin
  Randomize;

  tempFileName := 'tempFlights.txt';
  AssignFile(TempFile, tempFileName);
  Rewrite(TempFile);

  usedCodes := TStringList.Create;
  try
    for i := 0 to High(AirplaneNames) do
    begin
      flightCode := GenerateUniqueFlightCode(usedCodes);
      dVariedPrice := basePrice * (1 + ((Random(31) - 15) / 100)); // ±15%
      line := Format('%s %s%%%.2f', [AirplaneNames[i], flightCode,
        dVariedPrice]);
      WriteLn(TempFile, line);
    end;
  finally
    usedCodes.Free;
    CloseFile(TempFile);
  end;
end;

function TfrmBookFlights.GenerateUnqiueFlightNumber(existingList
  : TStringList): string;
var
  airlineCode: string;
  flightNum: string;
begin
  repeat
    // Random 3-letter airline code
    airlineCode := Chr(65 + Random(26)) + Chr(65 + Random(26)) +
      Chr(65 + Random(26));

    // Random 4-digit number
    flightNum := Format('%s%d', [airlineCode, 1000 + Random(9000)]);

  until existingList.IndexOf(flightNum) = -1; // Ensure uniqueness

  Result := flightNum;
end;

function TfrmBookFlights.GetLabelByDestination(const destination
  : string): TLabel;
var
  i: Integer;
  ctrlName: string;
begin

  ctrlName := 'lbl' + StringReplace(destination, ' ', '', [rfReplaceAll]);
  for i := 0 to ComponentCount - 1 do
  begin
    if (Components[i] is TLabel) and
      (CompareText(Components[i].Name, ctrlName) = 0) then
    begin
      Result := TLabel(Components[i]);
      Exit;
    end;
  end;

  Result := nil;

end;

procedure TfrmBookFlights.lblAfricaClick(Sender: TObject);
begin

  pnlContinents.Hide;
  pnlContinents.Visible := False;
  pnlAfrica.Show;

end;

procedure TfrmBookFlights.lblAlgeriaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblAlgeria);

end;

procedure TfrmBookFlights.lblAngolaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblAngola);

end;

procedure TfrmBookFlights.lblArgentinaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblArgentina);

end;

procedure TfrmBookFlights.lblAsiaClick(Sender: TObject);
begin

  pnlContinents.Hide;
  pnlContinents.Visible := False;
  pnlAsia.Show;

end;

procedure TfrmBookFlights.lblAustralia2Click(Sender: TObject);
begin

  SelectCountryFromLabel(lblAustralia);

end;

procedure TfrmBookFlights.lblAustraliaClick(Sender: TObject);
begin

  pnlContinents.Hide;
  pnlContinents.Visible := False;
  pnlAustralia.Show;

end;

procedure TfrmBookFlights.lblBelarusClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblBelarus);

end;

procedure TfrmBookFlights.lblBoliviaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblBolivia);

end;

procedure TfrmBookFlights.lblBotswanaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblBotswana);

end;

procedure TfrmBookFlights.lblBrazilClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblBrazil);

end;

procedure TfrmBookFlights.lblBulgariaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblBulgaria);

end;

procedure TfrmBookFlights.lblBurkinaFasoClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblBurkinaFaso);

end;

procedure TfrmBookFlights.lblCameroonClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblCameroon);

end;

procedure TfrmBookFlights.lblCanadaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblCanada);

end;

procedure TfrmBookFlights.lblChadClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblChad);

end;

procedure TfrmBookFlights.lblChileClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblChile);

end;

procedure TfrmBookFlights.lblChinaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblChina);

end;

procedure TfrmBookFlights.lblColombiaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblColombia);

end;

procedure TfrmBookFlights.lblDemocraticRepublicCongoClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblDemocraticRepublicCongo);

end;

procedure TfrmBookFlights.lblEcuadorClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblEcuador);

end;

procedure TfrmBookFlights.lblEgyptClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblEgypt);

end;

procedure TfrmBookFlights.lblEthiopiaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblEthiopia);

end;

procedure TfrmBookFlights.lblEuropeClick(Sender: TObject);
begin

  pnlContinents.Hide;
  pnlContinents.Visible := False;
  pnlEurope.Show;

end;

procedure TfrmBookFlights.lblFinlandClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblFinland);

end;

procedure TfrmBookFlights.lblFranceClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblFrance);

end;

procedure TfrmBookFlights.lblGabonClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblGabon);

end;

procedure TfrmBookFlights.lblGermanyClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblGermany);

end;

procedure TfrmBookFlights.lblGhanaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblGhana);

end;

procedure TfrmBookFlights.lblGreeceClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblGreece);

end;

procedure TfrmBookFlights.lblGuinaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblGuina);

end;

procedure TfrmBookFlights.lblGuineaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblGuinea);

end;

procedure TfrmBookFlights.lblGuyanaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblGuyana);

end;

procedure TfrmBookFlights.lblHungaryClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblHungary);

end;

procedure TfrmBookFlights.lblIcelandClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblIceland);

end;

procedure TfrmBookFlights.lblIndiaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblIndia);

end;

procedure TfrmBookFlights.lblIranClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblIran);

end;

procedure TfrmBookFlights.lblIrelandClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblIreland);

end;

procedure TfrmBookFlights.lblItalyClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblItaly);

end;

procedure TfrmBookFlights.lblJapanClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblJapan);

end;

procedure TfrmBookFlights.lblKazakhstanClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblKazakhstan);

end;

procedure TfrmBookFlights.lblKenyaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblKenya);

end;

procedure TfrmBookFlights.lblLibyaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblLibya);

end;

procedure TfrmBookFlights.lblLithuaniaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblLithuania);

end;

procedure TfrmBookFlights.lblMaliClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblMali);

end;

procedure TfrmBookFlights.lblMauritaniaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblMauritania);

end;

procedure TfrmBookFlights.lblMexicoClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblMexico);

end;

procedure TfrmBookFlights.lblMongoliaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblMongolia);

end;

procedure TfrmBookFlights.lblMozambiqueClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblMozambique);

end;

procedure TfrmBookFlights.lblNamibiaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblNamibia);

end;

procedure TfrmBookFlights.lblNigerClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblNiger);

end;

procedure TfrmBookFlights.lblNigeriaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblNigeria);

end;

procedure TfrmBookFlights.lblNorthAmericaClick(Sender: TObject);
begin

  pnlContinents.Hide;
  pnlContinents.Visible := False;
  pnlNorthAmerica.Show;

end;

procedure TfrmBookFlights.lblNorwayClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblNorway);

end;

procedure TfrmBookFlights.lblPakistanClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblPakistan);

end;

procedure TfrmBookFlights.lblParaguayClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblParaguay);

end;

procedure TfrmBookFlights.lblPeruClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblPeru);

end;

procedure TfrmBookFlights.lblPolandClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblPoland);

end;

procedure TfrmBookFlights.lblPortugalClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblPortugal);

end;

procedure TfrmBookFlights.lblRomaniaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblRomania);

end;

procedure TfrmBookFlights.lblRussia2Click(Sender: TObject);
begin

  SelectCountryFromLabel(lblRussia)

end;

procedure TfrmBookFlights.lblRussiaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblRussia);

end;

procedure TfrmBookFlights.lblSenegalClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblSenegal);
end;

procedure TfrmBookFlights.lblSingaporeClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblSingapore);

end;

procedure TfrmBookFlights.lblSouthAfricaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblSouthAfrica);

end;

procedure TfrmBookFlights.lblSouthAmericaClick(Sender: TObject);
begin

  pnlContinents.Hide;
  pnlContinents.Visible := False;
  pnlSouthAmerica.Show;

end;

procedure TfrmBookFlights.lblSpainClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblSpain);

end;

procedure TfrmBookFlights.lblSudanClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblSudan);

end;

procedure TfrmBookFlights.lblSurinameClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblSuriname);

end;

procedure TfrmBookFlights.lblSwedenClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblSweden);

end;

procedure TfrmBookFlights.lblTanzaniaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblTanzania);

end;

procedure TfrmBookFlights.lblThailandClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblThailand);

end;

procedure TfrmBookFlights.lblTurkeyClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblTurkey);

end;

procedure TfrmBookFlights.lblUkraineClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblUkraine);

end;

procedure TfrmBookFlights.lblUnitedKingdomClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblUnitedKingdom);

end;

procedure TfrmBookFlights.lblUnitedStatesClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblUnitedStates);

end;

procedure TfrmBookFlights.lblUruguayClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblUruguay);

end;

procedure TfrmBookFlights.lblUSClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblUnitedStates);

end;

procedure TfrmBookFlights.lblVenezuelaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblVenezuela);

end;

procedure TfrmBookFlights.lblZambiaClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblZambia);

end;

procedure TfrmBookFlights.lblZimbabweClick(Sender: TObject);
begin

  SelectCountryFromLabel(lblZimbabwe);

end;

procedure TfrmBookFlights.rgClassesClick(Sender: TObject);
begin

  case rgClasses.ItemIndex of

    0:
      dMultiplier := 1.0;
    1:
      dMultiplier := 1.25;
    2:
      dMultiplier := 1.5;

  else
    dMultiplier := 1.0;

  end;

end;

procedure TfrmBookFlights.SelectCountryFromLabel(Sender: TObject);
var
  sInput, sDecision: String;
  iIndex: Integer;
begin

  sInput := TLabel(Sender).Caption;

  sDecision := LowerCase(InputBox('A-Way Airlines',
    'Please enter "From" or "To": ', ''));

  if sDecision = 'from' then
  begin

    iIndex := cmbDestinationFrom.Items.IndexOf(sInput);
    if iIndex <> -1 then
      cmbDestinationFrom.ItemIndex := iIndex;

  end
  else if sDecision = 'to' then
  begin

    iIndex := cmbDestinationTo.Items.IndexOf(sInput);
    if iIndex <> -1 then
      cmbDestinationTo.ItemIndex := iIndex;

  end;
end;

procedure TfrmBookFlights.SetupAvailableFlightsGrid;
var
  iColWidth: Integer;
begin
  sgAvailableFlights.ColCount := 3;
  sgAvailableFlights.FixedRows := 1;

  sgAvailableFlights.Cells[0, 0] := 'Airline';
  sgAvailableFlights.Cells[1, 0] := 'FlightNo';
  sgAvailableFlights.Cells[2, 0] := 'Price';

  iColWidth := sgAvailableFlights.ClientWidth div 3;
  sgAvailableFlights.ColWidths[0] := iColWidth;
  sgAvailableFlights.ColWidths[1] := iColWidth;
  sgAvailableFlights.ColWidths[2] := iColWidth;
end;

end.
