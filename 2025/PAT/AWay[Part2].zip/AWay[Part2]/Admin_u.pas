unit Admin_u;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, Vcl.Graphics, Math,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Data.DB, Vcl.Grids, Vcl.DBGrids,
  Vcl.ExtCtrls, Vcl.StdCtrls, dmAccounts_u;

type
  TfrmAdmin = class(TForm)
    imgAdminBackground: TImage;
    dbgProfiles: TDBGrid;
    lblAdminPanel: TLabel;
    btnAdminLogOut: TButton;
    btnCreate: TButton;
    btnUpdate: TButton;
    btnRemove: TButton;
    memPricing: TMemo;
    lblPricing: TLabel;
    btnUpdatePrice: TButton;
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure AutoSizeGridColumns(Grid: TDBGrid);
    procedure btnAdminLogOutClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure btnCreateClick(Sender: TObject);
    procedure btnRemoveClick(Sender: TObject);
    procedure btnUpdateClick(Sender: TObject);
    procedure btnUpdatePriceClick(Sender: TObject);
  private
    { Private declarations }
    LastSortedField: string;
    SortAscending: Boolean;

  public
    { Public declarations }
  end;

var
  frmAdmin: TfrmAdmin;

implementation

{$R *.dfm}

uses LoginRegister_u, BookFlights_u;

procedure TfrmAdmin.AutoSizeGridColumns(Grid: TDBGrid);
var
  i, VisibleCols: Integer;
  ColWidth: Integer;
begin
  VisibleCols := 0;

  // Count visible columns
  for i := 0 to Grid.Columns.Count - 1 do
    if Grid.Columns[i].Visible then
      Inc(VisibleCols);

  if VisibleCols = 0 then
    Exit;

  // Calculate width per column
  ColWidth := Grid.ClientWidth div VisibleCols;

  // Apply width
  for i := 0 to Grid.Columns.Count - 1 do
    if Grid.Columns[i].Visible then
      Grid.Columns[i].Width := ColWidth;
end;

procedure TfrmAdmin.btnAdminLogOutClick(Sender: TObject);
begin

  frmAdmin.Hide;
  frmLoginRegister.Show;

end;

procedure TfrmAdmin.btnCreateClick(Sender: TObject);
var
  sFirstName, sLastName, sEmail, sPassword: string;
  bIsAdmin: Boolean;
  sUserID: string;
  bAccountFound: Boolean;
begin
  // Ask admin for account details
  sFirstName := InputBox('New Account', 'Enter First Name:', '');
  if sFirstName = '' then
    Exit;

  sLastName := InputBox('New Account', 'Enter Last Name:', '');
  if sLastName = '' then
    Exit;

  sEmail := InputBox('New Account', 'Enter Email:', '');
  if sEmail = '' then
    Exit;

  sPassword := InputBox('New Account', 'Enter Password:', '');
  if sPassword = '' then
    Exit;

  bIsAdmin := MessageDlg('Should this user be an admin?', mtConfirmation,
    [mbYes, mbNo], 0) = mrYes;

  // Check if account already exists
  bAccountFound := False;
  with dmAccounts.tblAccounts do
  begin
    First;
    while not Eof do
    begin
      if LowerCase(FieldByName('Email').AsString) = LowerCase(sEmail) then
      begin
        bAccountFound := True;
        Break;
      end;
      Next;
    end;
  end;

  if bAccountFound then
  begin
    ShowMessage('An account with this email already exists.');
    Exit;
  end;

  // Create a unique UserID (same logic as registration)
  sUserID := LowerCase(Copy(sFirstName, 1, 3)) + LowerCase(Copy(sLastName, 1, 3)
    ) + LowerCase(Copy(sEmail, 1, 3)) + IntToStr(RandomRange(1, 101)) +
    IntToStr(RandomRange(1, 101));

  // Insert new account into database
  with dmAccounts.tblAccounts do
  begin
    Insert;
    FieldByName('UserID').AsString := sUserID;
    FieldByName('FirstName').AsString := sFirstName;
    FieldByName('LastName').AsString := sLastName;
    FieldByName('Email').AsString := LowerCase(sEmail);
    FieldByName('Password').AsString := sPassword;
    FieldByName('Admin').AsBoolean := bIsAdmin;
    Post;
  end;

  ShowMessage('New account created successfully! UserID: ' + sUserID);

  // Refresh admin grid (optional)
  dmAccounts.qryAccounts.Close;
  dmAccounts.qryAccounts.SQL.Text :=
    'SELECT * FROM tblAccounts ORDER BY FirstName, LastName';
  dmAccounts.qryAccounts.Open;

  AutoSizeGridColumns(dbgProfiles);
end;

procedure TfrmAdmin.btnRemoveClick(Sender: TObject);
var
  SelectedUserID: string;
begin
  if dmAccounts.tblAccounts.IsEmpty then
  begin
    ShowMessage('No users in the database.');
    Exit;
  end;

  SelectedUserID := dmAccounts.tblAccounts.FieldByName('UserID').AsString;

  if MessageDlg
    ('Are you sure you want to delete this user and all their flights?',
    mtConfirmation, [mbYes, mbNo], 0) <> mrYes then
    Exit;

  // Delete related flights first
  with dmAccounts.tblFlights do
  begin
    First;
    while not Eof do
    begin
      if FieldByName('UserID').AsString = SelectedUserID then
        Delete
      else
        Next;
    end;
  end;

  // Now delete the user
  dmAccounts.tblAccounts.Delete;

  ShowMessage('User and related flights successfully removed.');

  // Refresh the grids
  dmAccounts.qryAccounts.Close;
  dmAccounts.qryAccounts.SQL.Text :=
    'SELECT * FROM tblAccounts ORDER BY FirstName, LastName';
  dmAccounts.qryAccounts.Open;

  AutoSizeGridColumns(dbgProfiles);
end;

procedure TfrmAdmin.btnUpdateClick(Sender: TObject);
var
  SelectedUserID: string;
  NewFirstName, NewLastName, NewEmail, NewPassword: string;
  IsAdmin: Boolean;
begin
  // Make sure a record is selected
  if dmAccounts.tblAccounts.IsEmpty then
  begin
    ShowMessage('No users in the database.');
    Exit;
  end;

  // Get the UserID of the currently selected record
  SelectedUserID := dmAccounts.tblAccounts.FieldByName('UserID').AsString;

  // Ask for new details
  NewFirstName := InputBox('Edit User', 'Enter First Name:',
    dmAccounts.tblAccounts.FieldByName('FirstName').AsString);
  NewLastName := InputBox('Edit User', 'Enter Last Name:',
    dmAccounts.tblAccounts.FieldByName('LastName').AsString);
  NewEmail := InputBox('Edit User', 'Enter Email:',
    dmAccounts.tblAccounts.FieldByName('Email').AsString);
  NewPassword := InputBox('Edit User', 'Enter Password:',
    dmAccounts.tblAccounts.FieldByName('Password').AsString);
  IsAdmin := MessageDlg('Should this user be an admin?', mtConfirmation,
    [mbYes, mbNo], 0) = mrYes;

  // Edit the current record
  with dmAccounts.tblAccounts do
  begin
    Edit; // Put the dataset into edit mode
    FieldByName('FirstName').AsString := NewFirstName;
    FieldByName('LastName').AsString := NewLastName;
    FieldByName('Email').AsString := NewEmail;
    FieldByName('Password').AsString := NewPassword;
    FieldByName('Admin').AsBoolean := IsAdmin;
    Post; // Save changes
  end;

  ShowMessage('User updated successfully.');

  // Refresh the admin grid
  dmAccounts.qryAccounts.Close;
  dmAccounts.qryAccounts.SQL.Text :=
    'SELECT * FROM tblAccounts ORDER BY FirstName, LastName';
  dmAccounts.qryAccounts.Open;

  AutoSizeGridColumns(dbgProfiles);
end;

procedure TfrmAdmin.btnUpdatePriceClick(Sender: TObject);
begin

  frmBookFlights.pricePerPixel :=
    StrToFloat(InputBox('Pricing', 'Price per pixel distance: ', ''));

  memPricing.Lines.Clear;
  memPricing.Lines.Add('Price per pixel distance:');
  memPricing.Lines.Add(FloatToStr(frmBookFlights.pricePerPixel));

end;

procedure TfrmAdmin.FormClose(Sender: TObject; var Action: TCloseAction);
begin

  Application.Terminate;

end;

procedure TfrmAdmin.FormCreate(Sender: TObject);
begin

  dbgProfiles.DataSource := dmAccounts.dscAccounts;

  // Remove title bar and borders
  BorderStyle := bsNone;

  // Maximize to full screen
  SetBounds(0, 0, Screen.Width, Screen.Height);
  // Set Boundaries for screen dimensions
  WindowState := wsMaximized;

  // Load background image
  imgAdminBackground.Picture.LoadFromFile('Background.png');

  dbgProfiles.Left := (ClientWidth - dbgProfiles.Width) DIV 2;
  lblAdminPanel.Left := (ClientWidth - lblAdminPanel.Width) DIV 2;

  AutoSizeGridColumns(dbgProfiles);

end;

procedure TfrmAdmin.FormShow(Sender: TObject);
begin

  with dmAccounts do
  begin
    qryAccounts.Close;
    qryAccounts.SQL.Text := 'SELECT * FROM tblAccounts';
    qryAccounts.Open;
  end;

  memPricing.Lines.Clear;
  memPricing.Lines.Add('Price per pixel distance:');
  memPricing.Lines.Add(FloatToStr(frmBookFlights.pricePerPixel));

end;

end.
