object frmMyFlights: TfrmMyFlights
  Left = 0
  Top = 0
  Caption = 'A-Way Airlines'
  ClientHeight = 1061
  ClientWidth = 1920
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  OnClose = FormClose
  OnCreate = FormCreate
  OnShow = FormShow
  TextHeight = 15
  object imgMyFlightsBackground: TImage
    Left = 0
    Top = 0
    Width = 1920
    Height = 1061
    Align = alClient
    Stretch = True
    ExplicitLeft = 344
    ExplicitTop = 240
    ExplicitWidth = 105
    ExplicitHeight = 105
  end
  object lblBookedFlights: TLabel
    Left = 128
    Top = 128
    Width = 556
    Height = 48
    Caption = 'Flight Bookings'
    Font.Charset = OEM_CHARSET
    Font.Color = clWhite
    Font.Height = -48
    Font.Name = 'Terminal'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblMyFlightDetails: TLabel
    Left = 1128
    Top = 128
    Width = 519
    Height = 48
    Caption = 'Flight Details'
    Font.Charset = OEM_CHARSET
    Font.Color = clWhite
    Font.Height = -48
    Font.Name = 'Terminal'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object sgBookedFlights: TStringGrid
    Left = 128
    Top = 232
    Width = 873
    Height = 585
    TabOrder = 0
  end
  object btnRemove: TButton
    Left = 352
    Top = 840
    Width = 75
    Height = 25
    Caption = 'Remove'
    TabOrder = 1
    OnClick = btnRemoveClick
  end
  object btnUndo: TButton
    Left = 496
    Top = 840
    Width = 75
    Height = 25
    Caption = 'Undo'
    TabOrder = 2
    OnClick = btnUndoClick
  end
  object btnSearch: TButton
    Left = 207
    Top = 840
    Width = 75
    Height = 25
    Caption = 'Search'
    TabOrder = 3
    OnClick = btnSearchClick
  end
  object memFlightDetails: TMemo
    Left = 1128
    Top = 232
    Width = 521
    Height = 585
    TabOrder = 4
  end
  object btnMyFlightsBack: TButton
    Left = 40
    Top = 992
    Width = 75
    Height = 25
    Caption = 'Back'
    TabOrder = 5
    OnClick = btnMyFlightsBackClick
  end
end
