unit Profile_u;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls, Vcl.StdCtrls,
  dmAccounts_u;

type
  TfrmProfile = class(TForm)
    imgProfileBackground: TImage;
    memProfile: TMemo;
    lblProfileHeading: TLabel;
    btnEditProfile: TButton;
    btnProfileBack: TButton;
    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure btnProfileBackClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure btnEditProfileClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmProfile: TfrmProfile;

implementation

{$R *.dfm}

uses Home_u, LoginRegister_u;

procedure TfrmProfile.btnEditProfileClick(Sender: TObject);
var
  userID, newFirstName, newLastName, newEmail, newPassword: string;
begin
  userID := frmLoginRegister.sUserID;

  // Ask for new details
  newFirstName := InputBox('Edit First Name', 'Enter new first name:', '');
  newLastName := InputBox('Edit Last Name', 'Enter new last name:', '');
  newEmail := InputBox('Edit Email', 'Enter new email address:', '');
  newPassword := InputBox('Edit Password', 'Enter new password:', '');

  // Update the database � ensure table name matches your actual schema
  with dmAccounts do
  begin
    qryAccounts.Close;
    qryAccounts.SQL.Text := 'UPDATE tblAccounts SET ' +
      '[Firstname] = :fn, [Lastname] = :ln, [Email] = :em, [Password] = :pw ' +
      'WHERE [UserID] = :uid';

    qryAccounts.Parameters.ParamByName('fn').Value := newFirstName;
    qryAccounts.Parameters.ParamByName('ln').Value := newLastName;
    qryAccounts.Parameters.ParamByName('em').Value := newEmail;
    qryAccounts.Parameters.ParamByName('pw').Value := newPassword;
    qryAccounts.Parameters.ParamByName('uid').Value := userID;

    qryAccounts.ExecSQL;
  end;

  // Refresh the memo using updated values
  with dmAccounts do
  begin
    qryAccounts.Close;
    qryAccounts.SQL.Text :=
      'SELECT Firstname, Lastname, Email, Password FROM tblAccounts WHERE UserID = :UserID';
    qryAccounts.Parameters.ParamByName('UserID').Value := userID;
    qryAccounts.Open;

    if not qryAccounts.Eof then
    begin
      memProfile.Clear;
      memProfile.Lines.Add('Account Details');
      memProfile.Lines.Add('------------------------------');
      memProfile.Lines.Add('First Name: ' + qryAccounts.FieldByName('Firstname')
        .AsString);
      memProfile.Lines.Add('Last Name:  ' + qryAccounts.FieldByName('Lastname')
        .AsString);
      memProfile.Lines.Add('Email:      ' + qryAccounts.FieldByName('Email')
        .AsString);
      memProfile.Lines.Add('Password:   ' + qryAccounts.FieldByName('Password')
        .AsString);
      memProfile.Lines.Add('------------------------------');
    end
    else
      memProfile.Text := 'No account details found for this user.';
  end;
end;

procedure TfrmProfile.btnProfileBackClick(Sender: TObject);
begin

  frmProfile.Hide;
  frmHome.Show;

end;

procedure TfrmProfile.FormClose(Sender: TObject; var Action: TCloseAction);
begin

  Application.Terminate;

end;

procedure TfrmProfile.FormCreate(Sender: TObject);
begin

  // Remove title bar and borders
  BorderStyle := bsNone;

  // Maximize to full screen
  SetBounds(0, 0, Screen.Width, Screen.Height);
  // Set Boundaries for screen dimensions
  WindowState := wsMaximized;

  // Load background image
  imgProfileBackground.Picture.LoadFromFile('Background.png');

  memProfile.Left := (ClientWidth - memProfile.Width) DIV 2;
  memProfile.Top := (ClientHeight - memProfile.Height) DIV 2;
  lblProfileHeading.Left := (ClientWidth - lblProfileHeading.Width) DIV 2;
  btnEditProfile.Left := (ClientWidth - btnEditProfile.Width) DIV 2;

end;

procedure TfrmProfile.FormShow(Sender: TObject);
var
  userID, firstName, lastName, email, password: string;
begin
  userID := frmLoginRegister.sUserID;

  with dmAccounts do
  begin

    qryAccounts.Close;
    qryAccounts.SQL.Text :=
      'SELECT Firstname, Lastname, Email, Password FROM tblAccounts WHERE UserID = :UserID';
    qryAccounts.Parameters.ParamByName('UserID').Value := userID;
    qryAccounts.Open;

    if not qryAccounts.Eof then
    begin
      firstName := qryAccounts.FieldByName('Firstname').AsString;
      lastName := qryAccounts.FieldByName('Lastname').AsString;
      email := qryAccounts.FieldByName('Email').AsString;
      password := qryAccounts.FieldByName('Password').AsString;

      memProfile.Clear;
      memProfile.Lines.Add('Account Details');
      memProfile.Lines.Add('------------------------------');
      memProfile.Lines.Add('First Name: ' + firstName);
      memProfile.Lines.Add('Last Name:  ' + lastName);
      memProfile.Lines.Add('Email:      ' + email);
      memProfile.Lines.Add('Password:   ' + password);
      memProfile.Lines.Add('------------------------------');
    end
    else
      memProfile.Text := 'No account details found for this user.';

  end;
end;

end.
